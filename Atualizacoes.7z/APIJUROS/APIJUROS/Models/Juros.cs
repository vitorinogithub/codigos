using System;

namespace WebApi1
{
    public class Taxa
    {
        public double Juros
        {
            get { return 0.01; }
        }
    }
}
