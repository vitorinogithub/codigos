﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebApiCalculaJuros.Models
{
    public class Taxa
    {
        public double valorinicial { get; set; }
        public int meses { get; set; }
        public double Juros { get; set; }       
    }
}

